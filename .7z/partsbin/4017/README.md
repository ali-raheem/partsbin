# 4017

Then venerable one-hot decade counter.

* cp0 - clk
* cp1 - clock edge control
* mr - Master reset
* q59_b - Active low carry
* out_q - Active high output

