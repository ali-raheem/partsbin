# Parts bin

Random chunks of Verilog I occasionally use. Cleaning up code and adding it as I do so.

It's all been used in projects so should work. Some of it has been simulated too. Some even has testbenches.

