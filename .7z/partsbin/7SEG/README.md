# 7 Segment Driver

```
  --a--
 |     |
 f     b
 |--g--|
 e     c
 |     |
  --d--

g = bit 6, a = bit 0;
```

Binary to 7 segment driver with output enable.